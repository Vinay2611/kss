<?php
  require '../vendor/autoload.php';
  use net\authorize\api\contract\v1 as AnetAPI;
  use net\authorize\api\controller as AnetController;
  include_once "../../db_con.php";
  session_start();
  define("AUTHORIZENET_LOG_FILE", "phplog");

 $post_data=$_POST;

 chargeCreditCard($post_data,$con);

  function chargeCreditCard($post_data,$con=''){
      $success=false;
      $msg="";
      $error_msg="";
      $cardnumber=$_POST['cardnumber'];
      $cvc=$_POST['cvc'];
      $exp_month=$_POST['exp_month'];
      $exp_year=$_POST['exp_year'];
      $exp_data=$exp_year.'-'.$exp_month;

      $sub_total=$_SESSION["TransactionData"]["SubTotal"];
      $tax_total=$_SESSION["TransactionData"]["total_tax"];
      $shipping_total=(float)$_POST['shipping_method'];
      $total=$sub_total+$shipping_total+$tax_total;
      $shipping_add=array(
        'recipient_name' => $_POST['recipient_name'],
          'line1'=>$_POST['line1'],
          'line2'=>$_POST['line2'],
          'postal_code'=>$_POST['postal_code'],
          'city'=>$_POST['city'],
          'state'=>$_POST['state'],
      );
      $shipping_add=json_encode($shipping_add);
      $record_date=date('Y-m-d H:i:s');
      //$cartitems_old=$_SESSION["TransactionData"]["cart_items"];
      $product_detail=json_encode($_SESSION['TransactionData']['cart_items']);

      $user_id= $_SESSION['loggedId'];

      $stmt = $con->prepare("INSERT INTO transactions (user_id,gateway,token,product_detail,full_detail,shipping_address,billing_address,tax,shipping,sub_total,total,payment_status,entry_date,delivery_status,viewed,status,description,payment_id,payer_id) 
                VALUES ('$user_id','Credit Card','','$product_detail','','$shipping_add','','$tax_total','$shipping_total','$sub_total','$total','Pending','$record_date','','0','1','','','')");

      $stmt->execute();
      $refId=$con->lastInsertId();

      // Common setup for API credentials
      $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
      $merchantAuthentication->setName(\SampleCode\Constants::MERCHANT_LOGIN_ID);
      $merchantAuthentication->setTransactionKey(\SampleCode\Constants::MERCHANT_TRANSACTION_KEY);

      // Create the payment data for a credit card
      $creditCard = new AnetAPI\CreditCardType();
      $creditCard->setCardNumber("4111111111111111");
      $creditCard->setExpirationDate("1 2020");
      $creditCard->setCardCode("123");
      $paymentOne = new AnetAPI\PaymentType();
      $paymentOne->setCreditCard($creditCard);

      $order = new AnetAPI\OrderType();
      $order->setDescription("Kss Store Product Payment");
      $order->setInvoiceNumber("98100");

      //create a transaction
      $transactionRequestType = new AnetAPI\TransactionRequestType();
      $transactionRequestType->setTransactionType( "authCaptureTransaction"); 
      $transactionRequestType->setAmount($total);
      $transactionRequestType->setOrder($order);
      $transactionRequestType->setPayment($paymentOne);


      $request = new AnetAPI\CreateTransactionRequest();
      $request->setMerchantAuthentication($merchantAuthentication);
      $request->setRefId( $refId);
      $request->setTransactionRequest($transactionRequestType);
      $controller = new AnetController\CreateTransactionController($request);

      $response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);
      

      if ($response != null)
      {
        if($response->getMessages()->getResultCode() == \SampleCode\Constants::RESPONSE_OK)
        {
          $tresponse = $response->getTransactionResponse();
          
	        if ($tresponse != null && $tresponse->getMessages() != null)   
          {
              if($tresponse->getResponseCode()=="1"){

              }
            echo " Transaction Response code : " . $tresponse->getResponseCode() . "\n";
            echo "Charge Credit Card AUTH CODE : " . $tresponse->getAuthCode() . "\n";
            echo "Charge Credit Card TRANS ID  : " . $tresponse->getTransId() . "\n";
            echo " Code : " . $tresponse->getMessages()[0]->getCode() . "\n"; 
	          echo " Description : " . $tresponse->getMessages()[0]->getDescription() . "\n";
          }
          else
          {
            echo "Transaction Failed \n";
            if($tresponse->getErrors() != null)
            {
              echo " Error code  : " . $tresponse->getErrors()[0]->getErrorCode() . "\n";
              echo " Error message : " . $tresponse->getErrors()[0]->getErrorText() . "\n";            
            }
          }
        }
        else
        {
          echo "Transaction Failed \n";
          $tresponse = $response->getTransactionResponse();
          if($tresponse != null && $tresponse->getErrors() != null)
          {
            echo " Error code  : " . $tresponse->getErrors()[0]->getErrorCode() . "\n";
            echo " Error message : " . $tresponse->getErrors()[0]->getErrorText() . "\n";                      
          }
          else
          {
            echo " Error code  : " . $response->getMessages()->getMessage()[0]->getCode() . "\n";
            echo " Error message : " . $response->getMessages()->getMessage()[0]->getText() . "\n";
          }
        }      
      }
      else
      {
        echo  "No response returned \n";
      }

      return $response;
  }
  /*if(!defined('DONT_RUN_SAMPLES'))
      chargeCreditCard(\SampleCode\Constants::SAMPLE_AMOUNT);*/
?>
